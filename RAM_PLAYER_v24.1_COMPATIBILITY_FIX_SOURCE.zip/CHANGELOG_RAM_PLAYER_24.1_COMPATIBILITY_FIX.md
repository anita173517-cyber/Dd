# RAM PLAYER v24.1 — Stream Compatibility & Category Persistence

- Restored the v21 native User-Agent as the default identity for live streams.
- Changed the fresh-install defaults to AUTO_SMART with the v21-compatible native identity first / Compatibility Mode OFF; users can still select VLC, TiviMate, Smarters, or Chrome compatibility profiles manually.
- Replaced the one-shot 403/406 User-Agent retry with a bounded four-profile fallback sequence in AUTO_SMART mode. HTTP response-code exceptions are inspected through the cause chain.
- Preserved the existing v24 Media3 HLS/MPEG-TS, decoder fallback, audio recovery, black-screen recovery, network reconnect, and audio-device callback code.
- Preserved the existing profile-scoped soft-delete Category Manager and channel delete / Recycle Bin. Category exclusions are reapplied in `applyLoadedChannels()` after playlist loads, so a deleted category remains hidden across refreshes and app restarts for the same profile/account scope.
- Added a unit test for the v21 native User-Agent and ordered compatibility fallback profiles.

## Verification disclosure

Source-level changes and the offline structural verifier are run in this environment. An Android SDK / Gradle build and physical IPTV provider playback test are not available here; no claim of 100% playback success is made. The exact provider response, account permissions, stream URL validity, codec, and device decoder can still affect individual channels.
