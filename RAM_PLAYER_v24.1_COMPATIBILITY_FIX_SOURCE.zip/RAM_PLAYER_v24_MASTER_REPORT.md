# RAM PLAYER v24.0 — EXTREME UNLIMITED MASTER EDITION REPORT

- **Version**: `24.0` (`versionCode = 240`, `applicationId = com.harindra.iptvpro`)
- **Base Lineage**: `v20.0 Final Ultimate` → `v21.0 Extreme Audio & Delete` → `v22.0 Black-Screen Fix & Pro Engine` → `v23.0 Extensionless HLS & Smart UA` → **`v24.0 Extreme Unlimited Master Edition`**.
- **Zero Feature Removal Guarantee**: 100% of existing UI, 3D AMOLED glass icons, navigation, M3U/Xtream, EPG, PiP, Parental PIN, Recycle Bin (encrypted), Transactional Restore, Category/Channel Delete, 5-Second OK Hold Delete, SQLite Store, and MediaSessionService are preserved intact.

## New in v24.0
1. **Live Network-Change Auto-Reconnect (`ConnectivityManager.NetworkCallback`)**: Automatically detects Wi-Fi / Ethernet / Mobile drops and reconnects the active Live TV stream the instant connectivity returns (lifecycle-safe in `onStart`/`onStop`, zero leaks).
2. **Real-Time Bluetooth & HDMI Audio Output Callback (`AudioManager.registerAudioDeviceCallback`)**: Automatically adapts audio routing and passthrough/offload when Bluetooth headphones, soundbars, or HDMI ARC connect or disconnect during playback.
3. **8-Second Live Freeze Detector & Bounded Auto-Resync (`LiveFreezeDetector`)**: Detects silent Live TV freezes where `STATE_READY` + `isPlaying` stays stuck at the same playback position for 8 seconds, and performs a bounded `seekToDefaultPosition()` live-edge resync (max 2 per channel).
4. **Network-Aware `DefaultBandwidthMeter` (`setResetOnNetworkTypeChange(true)`) + `AdaptiveBufferAdvisor`**: Prevents Wi-Fi ↔ Mobile handoffs from poisoning bitrate estimation and recommends safe buffer profiles for 512MB TVs without OOM risk.
5. **Configurable Decoder Preference Mode & Video Scaling Mode**:
   - `DecoderPreferenceMode`: `Hardware + SW Fallback` (default), `Hardware Only`, `Compat Safe`.
   - `VideoScalingPreference`: `Scale to Fit` (default) vs `Scale to Fit with Cropping`.
6. **Automated Unit Test Suite (`RamPlayerV24MasterTest.kt`)**: Total **41 automated unit tests** across 5 test classes (`M3uParserTest`, `LiveTvBackgroundPlaybackControllerTest`, `RamPlayerV21MasterTest`, `RamPlayerV22ProEngineTest`, `RamPlayerV23UltraMasterTest`, `RamPlayerV24MasterTest`).

## Transparent Build & Test Disclosure
- **Offline Sandbox Checks (PASS)**: `scripts/verify_project.py` (XML, 57 drawables, 67 view IDs, R-symbol resolution, brace balance, duplicate-override/function checks, test symbol audit) and `unzip -t` archive integrity check **PASSED**.
- **Gradle / APK / Physical Device Tests**: Offline sandbox has no Android SDK or internet access; Gradle `testDebugUnitTest`, `assembleDebug`, and `assembleRelease` execute automatically in GitHub Actions (`.github/workflows/build_apk.yml` using Gradle 8.13, SDK 36, JDK 17). Physical Android TV playback testing remains pending user installation.
