# RAM PLAYER v24.1 — Compatibility Fix Edition

**Package ID:** `com.harindra.iptvpro` (`versionCode = 241`, `versionName = "24.1"`)  
**Base:** v24.0 Extreme Master Edition with v21-compatible native-first stream identity and bounded compatibility fallback.

## Key points
- Native v21 User-Agent is the AUTO_SMART first attempt; VLC / TiviMate / Smarters / Chrome profiles are bounded retries after HTTP 403/406.
- Whole-category soft-delete and individual-channel delete remain profile/account scoped and persist through playlist refreshes and app restarts.
- Recycle Bin restore, HLS/MPEG-TS compatibility, audio recovery, black-screen recovery, network reconnect, HDMI/Bluetooth audio callbacks, SQLite storage, and MediaSession features are retained from v24.0.

## Verify
```bash
python3 scripts/verify_project.py
./gradlew testDebugUnitTest assembleDebug assembleRelease
```

The offline structural verifier is included. A full Android Gradle build and physical IPTV provider/device playback validation must still be run in an Android SDK-enabled environment.
