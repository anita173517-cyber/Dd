# RAM PLAYER v24.1 — Compatibility Fix Edition

- **Base:** RAM PLAYER v24.0 Extreme Master Edition.
- **Application ID:** `com.harindra.iptvpro`
- **Version:** `24.1` (`versionCode = 241`)
- **Primary fix:** v21-compatible native User-Agent is now the default; compatibility mode defaults off on fresh installs. AUTO_SMART starts with the v21-compatible native identity and retries up to four alternate User-Agent profiles only after HTTP 403/406 failures.
- **Category deletion:** Existing Category Manager, profile/account-scoped soft deletion, Recycle Bin restore, and refresh filtering are preserved.
- **Preserved:** v21-v24 source features, including audio recovery, black-screen diagnostics/recovery, HLS/MPEG-TS compatibility, network reconnect, Bluetooth/HDMI audio callbacks, SQLite channel store, and MediaSession playback service.

## Test status

- Offline structural/resource verifier: PASS (see `scripts/verify_project.py`).
- ZIP integrity: to be checked after packaging.
- Android Gradle compile/unit tests and physical TV playback: not executed in this environment (Android SDK / online dependency resolution unavailable).
