package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v24.0 — Extreme Unlimited Master Edition Automated Unit Tests.
 */
class RamPlayerV24MasterTest {

    @Test
    fun liveFreezeDetectorTriggersBoundedResyncAfterConsecutiveStalls() {
        val detector = LiveFreezeDetector(requiredStallSamples = 2, maxResyncsPerChannel = 2)
        // Normal playback advancing -> never triggers
        assertFalse(detector.onSample(positionMs = 10_000L, isPlayingLiveReady = true))
        assertFalse(detector.onSample(positionMs = 14_000L, isPlayingLiveReady = true))

        // Frozen at 14_000L for 2 consecutive 4s samples -> triggers resync #1
        assertFalse(detector.onSample(positionMs = 14_000L, isPlayingLiveReady = true))
        assertTrue(detector.onSample(positionMs = 14_000L, isPlayingLiveReady = true))

        // Frozen again -> triggers resync #2
        assertFalse(detector.onSample(positionMs = 14_000L, isPlayingLiveReady = true))
        assertTrue(detector.onSample(positionMs = 14_000L, isPlayingLiveReady = true))

        // Max 2 resyncs reached -> stops looping
        assertFalse(detector.onSample(positionMs = 14_000L, isPlayingLiveReady = true))
        assertFalse(detector.onSample(positionMs = 14_000L, isPlayingLiveReady = true))

        // Reset on channel switch restores budget
        detector.resetForNewChannel()
        assertFalse(detector.onSample(positionMs = 5_000L, isPlayingLiveReady = true))
        assertFalse(detector.onSample(positionMs = 5_000L, isPlayingLiveReady = true))
        assertTrue(detector.onSample(positionMs = 5_000L, isPlayingLiveReady = true))
    }

    @Test
    fun adaptiveBufferAdvisorRecommendsSafeProfilesByRamAndRebufferRate() {
        assertEquals("LOW_MEM", AdaptiveBufferAdvisor.recommendBufferProfileId(isLowRamDevice = true, rebufferCount = 0, networkDegraded = false))
        assertEquals("STABLE", AdaptiveBufferAdvisor.recommendBufferProfileId(isLowRamDevice = false, rebufferCount = 4, networkDegraded = false))
        assertEquals("STABLE", AdaptiveBufferAdvisor.recommendBufferProfileId(isLowRamDevice = false, rebufferCount = 0, networkDegraded = true))
        assertEquals("ULTRA_ZAP", AdaptiveBufferAdvisor.recommendBufferProfileId(isLowRamDevice = false, rebufferCount = 0, networkDegraded = false))
    }

    @Test
    fun decoderPreferenceAndVideoScalingModesCycleSafely() {
        assertEquals(DecoderPreferenceMode.HARDWARE_WITH_FALLBACK, DecoderPreferenceMode.fromId(null))
        assertEquals(DecoderPreferenceMode.HARDWARE_ONLY, DecoderPreferenceMode.HARDWARE_WITH_FALLBACK.nextMode())
        assertEquals(DecoderPreferenceMode.COMPAT_SAFE, DecoderPreferenceMode.HARDWARE_ONLY.nextMode())
        assertEquals(DecoderPreferenceMode.HARDWARE_WITH_FALLBACK, DecoderPreferenceMode.COMPAT_SAFE.nextMode())

        assertEquals(VideoScalingPreference.FIT, VideoScalingPreference.fromId(null))
        assertEquals(VideoScalingPreference.CROP_FILL, VideoScalingPreference.FIT.nextMode())
        assertEquals(VideoScalingPreference.FIT, VideoScalingPreference.CROP_FILL.nextMode())
    }
    @Test
    fun nativeV21UserAgentIsDefaultAndFallbackProfilesAreDistinct() {
        val originalProfile = NetworkClient.activeUserAgentProfile
        val originalCompatibility = NetworkClient.compatibilityModeEnabled
        try {
            NetworkClient.activeUserAgentProfile = UserAgentProfile.AUTO_SMART
            NetworkClient.compatibilityModeEnabled = false
            assertEquals("RAMPlayer/21.0-AMOLED (AndroidTV)", NetworkClient.effectiveUserAgent())

            val first = NetworkClient.nextFallbackUserAgent(NetworkClient.effectiveUserAgent())
            val second = NetworkClient.nextFallbackUserAgent(first)
            val third = NetworkClient.nextFallbackUserAgent(second)
            assertEquals(UserAgentProfile.VLC_COMPAT.userAgentValue, first)
            assertEquals(UserAgentProfile.TIVIMATE_COMPAT.userAgentValue, second)
            assertEquals(UserAgentProfile.SMARTERS_COMPAT.userAgentValue, third)
        } finally {
            NetworkClient.activeUserAgentProfile = originalProfile
            NetworkClient.compatibilityModeEnabled = originalCompatibility
        }
    }

}
